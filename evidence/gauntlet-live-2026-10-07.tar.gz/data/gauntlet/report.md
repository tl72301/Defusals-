# Depot Gauntlet results

## Ladder A: Speed (deadline per package)

| Player | 1.5 s deadline | 1.0 s deadline | 0.75 s deadline | 0.5 s deadline |
|---|---:|---:|---:|---:|
| decisions | 92% (55/60) | 93% (56/60) | 95% (57/60) | 60% (36/60) |
| classifier | 62% (37/60) | 62% (37/60) | 62% (37/60) | 62% (37/60) |
| dictionary | 45% (27/60) | 45% (27/60) | 45% (27/60) | 45% (27/60) |
| keyword | 42% (25/60) | 42% (25/60) | 42% (25/60) | 42% (25/60) |
| random | 28% (17/60) | 25% (15/60) | 20% (12/60) | 35% (21/60) |
| oracle | 100% (60/60) | 100% (60/60) | 100% (60/60) | 100% (60/60) |

| Decisions detail | 1.5 s deadline | 1.0 s deadline | 0.75 s deadline | 0.5 s deadline |
|---|---:|---:|---:|---:|
| 95% CI | 82%-96% | 84%-97% | 86%-98% | 47%-71% |
| no answer (timeouts) | 4 (4) | 2 (2) | 3 (3) | 22 (22) |
| accuracy when answered | 98% | 97% | 100% | 95% |
| latency p50 / p95 (s) | 0.51 / 1.50 | 0.49 / 0.61 | 0.49 / 0.61 | 0.49 / 0.50 |

## Ladder B: Rule load

| Player | 1 rules | 5 rules | 10 rules | 20 rules | 10 rules + 4 exceptions |
|---|---:|---:|---:|---:|---:|
| decisions | 98% (39/40) | 85% (34/40) | 90% (36/40) | 95% (38/40) | 42% (17/40) |
| classifier | 88% (35/40) | 75% (30/40) | 80% (32/40) | 82% (33/40) | 70% (28/40) |
| dictionary | 68% (27/40) | 70% (28/40) | 75% (30/40) | 68% (27/40) | 68% (27/40) |
| keyword | 68% (27/40) | 72% (29/40) | 72% (29/40) | 70% (28/40) | 62% (25/40) |
| random | 65% (26/40) | 65% (26/40) | 57% (23/40) | 60% (24/40) | 40% (16/40) |
| oracle | 100% (40/40) | 100% (40/40) | 100% (40/40) | 100% (40/40) | 100% (40/40) |

| Decisions detail | 1 rules | 5 rules | 10 rules | 20 rules | 10 rules + 4 exceptions |
|---|---:|---:|---:|---:|---:|
| 95% CI | 87%-100% | 71%-93% | 77%-96% | 83%-99% | 29%-58% |
| no answer (timeouts) | 0 (0) | 1 (0) | 1 (0) | 0 (0) | 0 (0) |
| accuracy when answered | 98% | 87% | 92% | 95% | 42% |
| latency p50 / p95 (s) | 0.63 / 1.12 | 0.61 / 1.06 | 0.58 / 0.96 | 0.52 / 0.59 | 0.53 / 0.64 |

## Ladder C: Knowledge depth

| Player | everyday | specialist | expert | misleading | compound |
|---|---:|---:|---:|---:|---:|
| decisions | 100% (35/35) | 100% (40/40) | 97% (38/39) | 86% (32/37) | 82% (28/34) |
| classifier | 91% (32/35) | 68% (27/40) | 46% (18/39) | 49% (18/37) | 50% (17/34) |
| dictionary | 94% (33/35) | 38% (15/40) | 36% (14/39) | 32% (12/37) | 59% (20/34) |
| keyword | 74% (26/35) | 32% (13/40) | 33% (13/39) | 19% (7/37) | 62% (21/34) |
| random | 31% (11/35) | 15% (6/40) | 26% (10/39) | 24% (9/37) | 18% (6/34) |
| oracle | 100% (35/35) | 100% (40/40) | 100% (39/39) | 100% (37/37) | 100% (34/34) |

| Decisions detail | everyday | specialist | expert | misleading | compound |
|---|---:|---:|---:|---:|---:|
| 95% CI | 90%-100% | 91%-100% | 87%-100% | 72%-94% | 66%-92% |
| no answer (timeouts) | 0 (0) | 0 (0) | 0 (0) | 0 (0) | 0 (0) |
| accuracy when answered | 100% | 100% | 97% | 86% | 82% |
| latency p50 / p95 (s) | 0.47 / 0.56 | 0.48 / 0.56 | 0.47 / 0.55 | 0.45 / 0.53 | 0.49 / 0.58 |

## Ladder D: Messy input

| Player | light typos | heavy typos | scanner (OCR) errors | transliteration and mixed scripts | extreme |
|---|---:|---:|---:|---:|---:|
| decisions | 98% (39/40) | 82% (33/40) | 82% (33/40) | 100% (40/40) | 55% (22/40) |
| classifier | 60% (24/40) | 48% (19/40) | 42% (17/40) | 52% (21/40) | 40% (16/40) |
| dictionary | 30% (12/40) | 30% (12/40) | 25% (10/40) | 32% (13/40) | 25% (10/40) |
| keyword | 28% (11/40) | 35% (14/40) | 25% (10/40) | 30% (12/40) | 22% (9/40) |
| random | 35% (14/40) | 18% (7/40) | 32% (13/40) | 30% (12/40) | 22% (9/40) |
| oracle | 100% (40/40) | 100% (40/40) | 100% (40/40) | 100% (40/40) | 100% (40/40) |

| Decisions detail | light typos | heavy typos | scanner (OCR) errors | transliteration and mixed scripts | extreme |
|---|---:|---:|---:|---:|---:|
| 95% CI | 87%-100% | 68%-91% | 68%-91% | 91%-100% | 40%-69% |
| no answer (timeouts) | 0 (0) | 0 (0) | 0 (0) | 0 (0) | 0 (0) |
| accuracy when answered | 98% | 82% | 82% | 100% | 55% |
| latency p50 / p95 (s) | 0.48 / 0.78 | 0.48 / 0.60 | 0.47 / 0.88 | 0.48 / 0.66 | 0.47 / 0.70 |

## Ladder A: throughput (many packages per request, 200 packages total)

| Packages per request | Requests | Accuracy | No answer | Seconds per request (p50) | Wall time | Packages per second | Input tokens per package |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 200 | 97% | 1 | 0.49 | 119.9 s | 1.7 | 258 |
| 10 | 20 | 92% | 10 | 0.50 | 16.1 s | 12.4 | 140 |
| 50 | 4 | 98% | 0 | 0.59 | 2.6 s | 76.6 | 138 |
| 200 | 1 | 97% | 0 | 1.14 | 1.2 s | 165.0 | 136 |

Decisions cost from returned usage: $0.0363

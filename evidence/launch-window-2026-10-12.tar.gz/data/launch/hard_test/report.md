# Launch Window results (hard_test)

| System | False clears (scenarios) | Unjustified holds | Polls in wrong state | Launch chances used | Clarifications | Cost |
|---|---:|---:|---:|---:|---:|---:|
| oracle | 0 (0) | 0 | 0 of 144 | 82 of 107 | 9 | $0.0000 |
| parser | 0 (0) | 78 | 107 of 144 | 0 of 107 | 5 | $0.0000 |
| decisions-top | 0 (0) | 1 | 3 of 144 | 81 of 107 | 10 | $0.0557 |
| decisions-threshold | 0 (0) | 1 | 3 of 144 | 80 of 107 | 56 | $0.0644 |
| decisions-sensitive | 0 (0) | 1 | 3 of 144 | 81 of 107 | 11 | $0.0559 |
| responses-luna-none | 6 (3) | 2 | 8 of 144 | 85 of 107 | 9 | $0.0514 |
| responses-luna-medium | 0 (0) | 13 | 15 of 144 | 69 of 107 | 9 | $0.0655 |

H1 (sensitive fewer false clears than top): sensitive fewer in 0 scenarios, more in 0, ties 16; one-sided sign test p = 1.000

| System | OBS_TIME | WIND | TEMP_LOW | TEMP_HIGH | PRECIP | LIGHTNING | FIELDMILL | SOLAR | CORRECTION |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| oracle | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% |
| parser | 83% | 91% | 38% | 51% | 89% | 98% | 52% | 99% | 100% |
| decisions-top | 99% | 100% | 100% | 100% | 100% | 99% | 100% | 99% | 46% |
| decisions-threshold | 99% | 100% | 100% | 100% | 100% | 99% | 100% | 99% | 46% |
| decisions-sensitive | 99% | 100% | 100% | 100% | 100% | 99% | 100% | 99% | 46% |
| responses-luna-none | 100% | 100% | 99% | 98% | 100% | 97% | 100% | 100% | 97% |
| responses-luna-medium | 100% | 100% | 100% | 100% | 100% | 89% | 100% | 100% | 100% |

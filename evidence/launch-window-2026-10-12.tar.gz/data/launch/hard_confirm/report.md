# Launch Window results (hard_confirm)

| System | False clears (scenarios) | Unjustified holds | Polls in wrong state | Launch chances used | Clarifications | Cost |
|---|---:|---:|---:|---:|---:|---:|
| oracle | 0 (0) | 0 | 0 of 360 | 198 of 274 | 25 | $0.0000 |
| parser | 0 (0) | 196 | 265 of 360 | 0 of 274 | 11 | $0.0000 |
| decisions-top | 5 (2) | 3 | 9 of 360 | 197 of 274 | 28 | $0.1429 |
| responses-luna-none | 5 (4) | 7 | 17 of 360 | 193 of 274 | 26 | $0.1318 |
| responses-luna-none-raw | 3 (2) | 1 | 6 of 360 | 199 of 274 | 27 | $0.1353 |

| System | OBS_TIME | WIND | TEMP_LOW | TEMP_HIGH | PRECIP | LIGHTNING | FIELDMILL | SOLAR | CORRECTION |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| oracle | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% |
| parser | 79% | 94% | 45% | 57% | 95% | 92% | 51% | 99% | 100% |
| decisions-top | 98% | 99% | 100% | 100% | 100% | 100% | 99% | 100% | 42% |
| responses-luna-none | 99% | 99% | 100% | 99% | 100% | 97% | 100% | 99% | 97% |
| responses-luna-none-raw | 100% | 99% | 100% | 100% | 100% | 100% | 100% | 100% | 95% |

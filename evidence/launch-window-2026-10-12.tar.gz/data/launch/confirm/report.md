# Launch Window results (confirm)

| System | False clears (scenarios) | Unjustified holds | Polls in wrong state | Launch chances used | Clarifications | Cost |
|---|---:|---:|---:|---:|---:|---:|
| oracle | 0 (0) | 0 | 0 of 360 | 193 of 258 | 23 | $0.0000 |
| parser | 29 (14) | 14 | 59 of 360 | 174 of 258 | 24 | $0.0000 |
| decisions-top | 2 (2) | 3 | 6 of 360 | 188 of 258 | 32 | $0.1394 |
| responses-luna-none | 4 (3) | 2 | 12 of 360 | 192 of 258 | 27 | $0.1279 |
| responses-luna-none-raw | 1 (1) | 0 | 3 of 360 | 194 of 258 | 28 | $0.1313 |

| System | OBS_TIME | WIND | TEMP_LOW | TEMP_HIGH | PRECIP | LIGHTNING | FIELDMILL | SOLAR | CORRECTION |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| oracle | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% |
| parser | 99% | 93% | 89% | 97% | 100% | 97% | 99% | 98% | 100% |
| decisions-top | 98% | 98% | 99% | 99% | 100% | 98% | 100% | 100% | 57% |
| responses-luna-none | 99% | 100% | 100% | 100% | 100% | 99% | 100% | 99% | 100% |
| responses-luna-none-raw | 100% | 100% | 100% | 100% | 100% | 99% | 100% | 100% | 100% |

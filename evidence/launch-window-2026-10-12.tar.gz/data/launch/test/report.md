# Launch Window results (test)

| System | False clears (scenarios) | Unjustified holds | Polls in wrong state | Launch chances used | Clarifications | Cost |
|---|---:|---:|---:|---:|---:|---:|
| oracle | 0 (0) | 0 | 0 of 216 | 133 of 164 | 16 | $0.0000 |
| parser | 13 (6) | 19 | 37 of 216 | 113 of 164 | 11 | $0.0000 |
| decisions-top | 0 (0) | 0 | 0 of 216 | 130 of 164 | 22 | $0.0840 |
| decisions-threshold | 0 (0) | 3 | 3 of 216 | 124 of 164 | 87 | $0.0964 |
| decisions-sensitive | 0 (0) | 0 | 0 of 216 | 130 of 164 | 24 | $0.0844 |
| responses-luna-none | 0 (0) | 4 | 4 of 216 | 127 of 164 | 16 | $0.0765 |
| responses-luna-medium | 0 (0) | 2 | 2 of 216 | 131 of 164 | 17 | $0.0922 |

H1 (sensitive fewer false clears than top): sensitive fewer in 0 scenarios, more in 0, ties 24; one-sided sign test p = 1.000

| System | OBS_TIME | WIND | TEMP_LOW | TEMP_HIGH | PRECIP | LIGHTNING | FIELDMILL | SOLAR | CORRECTION |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| oracle | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% |
| parser | 99% | 96% | 90% | 95% | 100% | 97% | 100% | 98% | 100% |
| decisions-top | 97% | 97% | 100% | 100% | 100% | 99% | 100% | 99% | 55% |
| decisions-threshold | 97% | 97% | 100% | 100% | 100% | 99% | 100% | 99% | 55% |
| decisions-sensitive | 97% | 97% | 100% | 100% | 100% | 99% | 100% | 99% | 55% |
| responses-luna-none | 98% | 100% | 99% | 100% | 100% | 100% | 100% | 98% | 100% |
| responses-luna-medium | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% | 100% |
